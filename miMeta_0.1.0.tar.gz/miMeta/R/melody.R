#' @title Meta-analysis for selecting microbial signatures associated with covariate of interests.
#'
#' @description Melody is a meta-analysis method designed to account for the unique features of compositional microbiome data
#' in selecting microbial signatures.
#'
#' @author Zhoujingpeng Wei, Guanhua Chen, Zheng-Zheng Tang
#'
#' @param rel.abd A list of matrices for relative abundance counts. Each element of the list pertains to one study,
#' and the name of each element must be the study ID. Each matrix must have sample IDs as row names and microbial feature IDs as column names.
#' No missing value is allowed.
#' @param covariate.interest A list of matrices for single or multiple covariates of interest. Each element of the list pertains to one study, and the name of each element must be
#' the study ID. In a matrix of a given study, each row is a sample, and each column is a covariate of interest and can only be a numeric vector.
#' The set of covariates can be different among studies. In a given study, the order of samples should be matched with the order in "rel.abd". No missing value is allowed.
#' @param covariate.adjust A list of data frames for covariates that will be adjusted for in the model. Each element of the list pertains to one study,
#' and the name of each element must be the study ID. In a data frame of a given study, each row is a sample, and each column is a covariate to be adjusted and can only be a factor or numeric vector.
#' The set of covariates can be different among studies. In a given study, the order of samples should be matched with the order in "rel.abd". No missing value is allowed.
#' Default is NULL (not adjusting for any covariates)
#' @param cluster A list of vectors of variable that define the sample cluster for studies with correlated samples. Each element of the list pertains to one study with correlated samples,
#' and the name of each element must be the study ID. The order of samples should be matched with the order in "rel.abd" in the corresponding study.
#' For example, the values of this variable are subject IDs if each subject has multiple correlated samples
#' (e.g., measured in a longitudinal study). Default is NULL (all samples in all studies are independent, so no need to provide this input.).
#' @param depth.filter A cutoff value to remove samples with sequencing depth less than or equal to the cutoff. Default is 0.
#' @param prev.filter A cutoff value remove microbial features with prevalence (proportion of nonzero observations)
#' less than or equal to the cutoff. This cutoff is applied to each study. So, a feature could be removed in a subset of the studies. The cutoff value must be in the range of 0-1. Default is 0.1.
#' @param ref A feature ID or a vector of feature IDs. If a feature ID is provided, this microbial feature will be used as the reference in all studies when generating summary statistics.
#' If a vector of feature IDs is provided, each feature in the vector will be the reference for a study. Therefore, the length of the vector should be equal to the number of studies and have study IDs as names.
#' Default is NULL (the function will automatically pick reference for each study).
#' @param tune.path Method to choose the optimal subset size in the best subset selection. If tune.path is "sequence",
#' we solve the best subset selection problem for each size in "tune size sequence". If tune.path is "gsection",
#' we solve the best subset selection problem with the size ranged in tune.size.range, where the considered size
#' sequence within the range is determined by golden section search. Default is "gsection".
#' @param tune.size.sequence An integer vector containing the subset sizes to be considered. Only used when tune.path is "sequence".
#' Default is 0:round(K/2), where K is number of microbial features.
#' @param tune.size.range An integer vector with two elements that define the range of the size. Default is c(0, K/2)
#' @param tune.type Type of information criterion for choosing the best subset size. Available options are "BIC", "HBIC", "KBIC" and "EBIC".
#' Default is "BIC".
#' @param tol Convergence tolerance in the search for the best delta tuning parameters. Default is 1e-3.
#' @param NMAX The maximum number of iterations in the search for the best delta tuning parameters. Default is 20.
#' @param parallel.core The number of cores to be concurrently used for generating summary statistics.
#' It's an integer between 1 and cl - 1 (cl is the total core number). Default is cl - 1.
#' @param ouput.best.one Whether only output the best model. Default is TRUE.
#' @param verbose: Whether to print verbose information. Default is FALSE. (see details in Value)
#'
#' @return Output a list with each component for a covariate of interest.
#'
#' If output.best.one=TRUE (default), the component includes the following elements to deliver the meta-analysis results under the best model over the subset sizes considered.
#' \item{coef}{A coefficient vector that contains the meta association coefficient estimate (at the absolute-abundance level) under the best subset size. The vector names are microbial features IDs. The microbial features with nonzero coefficients are the selected signatures.}
#' \item{delta}{A vector that contains the best values of the delta tuning parameters under the best subset size. The vector names are in the format "<study ID>_<reference microbial feature ID>"}
#' \item{dev}{The value of the deviance for the best subset size.}
#' \item{ic}{The value of the information criterion (the type of information criterion is specified in tune.type) for the best subset size.}
#'
#' If output.best.one=FALSE, the component includes the following elements to deliver the meta-analysis results under all models over the subset sizes considered. (depends on tune.path, see details in Arguments)
#' \item{coef}{A coefficient matrix with each column contains the  meta association coefficient estimate (at the absolute-abundance level) under a subset size. The row names are microbial features IDs and the column names are the subset sizes considered.}
#' \item{delta}{A matrix with each column contains the best values of the delta tuning parameters under a subset size. The row names are in the format "<study ID>_<reference microbial feature ID>" and the column names are the subset sizes considered.}
#' \item{dev}{A vector contains the values of the deviance for the subset sizes considered.}
#' \item{ic}{A vector contains the values of the information criterion (the type of information criterion is specified in tune.type) for the subset sizes considered.}
#'
#' If verbose=TRUE, print out information about the progress of the meta-analysis. In addition,
#' it will generate an intersection plot showing the number of microbial features shared among studies and scatter
#' plots for the meta-coefficient estimates for the top 5 covariates of interest associated with most microbial features.
#'
#' @details
#' Melody first generates summary statistics (microbiome association coefficient estimates and their variances) for
#' individual studies. Melody then combines the summary statistics across studies to select microbial signatures.
#' In particular, the selection of signature is operated through a best-subset selection.
#' There are two sets of tuning parameters in the best subset selection including the subset size
#' (i.e. the number of microbial features selected) and delta's which are introduced to recover the
#' absolute-abundance coefficients from the relative-abundance coefficients. (details in reference Wei et al.)
#'
#' @references Wei Z, Chen G, Tang ZZ. Melody: Meta-analysis of Microbiome Association Studies for Discovering Generalizable Microbial Signatures. Submitted.
#'
#' @seealso \code{\link{melody.get.summary}},
#' \code{\link{melody.meta.summary}},
#' \code{\link{melody.null.model}}
#'
#' @importFrom brglm2 brglmFit
#' @export
#'
#' @examples
#' \donttest{
#' library("miMeta")
#' data("CRC_data")
#' CRC_abd <- CRC_data$CRC_abd
#' CRC_meta <- CRC_data$CRC_meta
#'
#' ########## Generate summary statistics ##########
#' rel.abd <- list()
#' covariate.interest <- list()
#' for(d in unique(CRC_meta$Study)){
#'   rel.abd[[d]] <- CRC_abd[CRC_meta$Sample_ID[CRC_meta$Study == d],]
#'   disease <- as.numeric(CRC_meta$Group[CRC_meta$Study == d] == "CRC")
#'   names(disease) <- CRC_meta$Sample_ID[CRC_meta$Study == d]
#'   covariate.interest[[d]] <- matrix(disease, ncol = 1, dimnames = list(names(disease), "disease"))
#' }
#'
#' meta.result <- melody(rel.abd = rel.abd, covariate.interest = covariate.interest,
#'                       ref = "Coprococcus catus [ref_mOTU_v2_4874]")
#' }
#'

melody <- function(rel.abd,
                   covariate.interest,
                   covariate.adjust = NULL,
                   cluster = NULL,
                   depth.filter = 0,
                   prev.filter = 0.1,
                   ref = NULL,
                   tune.path = c("gsection", "sequence"),
                   tune.size.sequence = NULL,
                   tune.size.range = NULL,
                   tune.type = c("BIC", "HBIC", "KBIC", "EBIC"),
                   tol = 1e-3,
                   NMAX = 20,
                   parallel.core = NULL,
                   output.best.one = TRUE,
                   verbose = FALSE
) {

  tune.path <- match.arg(tune.path)
  tune.type <- match.arg(tune.type)

  #=== Generate summary statistics ===#
  null.obj <- melody.null.model(rel.abd = rel.abd,
                                covariate.adjust = covariate.adjust,
                                depth.filter = depth.filter,
                                prev.filter = prev.filter,
                                ref = ref,
                                parallel.core = parallel.core)

  summary.stats <- melody.get.summary(null.obj = null.obj,
                                      covariate.interest = covariate.interest,
                                      cluster = cluster,
                                      verbose = verbose)

  # Meta-analysis
  Melody.model <- melody.meta.summary(summary.stats = summary.stats,
                                      tune.path = tune.path,
                                      tune.size.sequence = tune.size.sequence,
                                      tune.size.range = tune.size.range,
                                      tune.type = tune.type,
                                      output.best.one = output.best.one,
                                      tol = tol,
                                      verbose = verbose)

  return(Melody.model)
}
