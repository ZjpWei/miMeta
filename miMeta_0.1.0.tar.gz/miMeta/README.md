## miMeta

`miMeta` is a R package and it implements the new methods for meta-analysis of microbiome association studies that respect the unique features of microbiome data such as compositionality.

See following items for more details:

* Manual.

* Tutorial

* The article: Wei Z, Chen G, Tang ZZ. Melody identifies generalizable microbial signatures in microbiome association meta-analysis. Submitted.

## Author

Zhoujingpeng Wei @[Tang](https://tangzheng1.github.io/tanglab/)


