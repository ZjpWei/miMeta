## ----getPackage, echo=TRUE----------------------------------------------------
if(!require("miMeta", quietly = TRUE)){
  devtools::install_github("ZjpWei/miMeta")
}

## ----load, echo=TRUE, message=FALSE, warning=FALSE----------------------------
library("miMeta")
library("tidyverse")

## ----echo=TRUE----------------------------------------------------------------
data("CRC_data")
CRC_abd <- CRC_data$CRC_abd
CRC_meta <- CRC_data$CRC_meta

## ----echo=TRUE, message=TRUE, warning=FALSE-----------------------------------
# Prepare input data
rel.abd <- list()
covariate.interest <- list()
for(d in c("FR-CRC", "DE-CRC")){
  rel.abd[[d]] <- CRC_abd[CRC_meta$Sample_ID[CRC_meta$Study == d],]
  disease <- as.numeric(CRC_meta$Group[CRC_meta$Study == d] == "CRC")
  names(disease) <- CRC_meta$Sample_ID[CRC_meta$Study == d]
  covariate.interest[[d]] <- data.frame(disease = disease)
}

refs <- c("Coprococcus catus [ref_mOTU_v2_4874]", "Coprococcus catus [ref_mOTU_v2_4874]")
names(refs) <- c("FR-CRC", "DE-CRC")
meta.result <- melody(rel.abd = rel.abd, covariate.interest = covariate.interest, 
                      ref = refs, 
                      verbose = TRUE)

## -----------------------------------------------------------------------------
head(data.frame(coef = meta.result$disease$coef), n = 20)

## ----echo=TRUE, message=FALSE, warning=FALSE----------------------------------
# Generate summary statistics for each study
null.obj.FR <- melody.null.model(rel.abd = rel.abd["FR-CRC"], ref = "Coprococcus catus [ref_mOTU_v2_4874]")
summary.stats.FR <- melody.get.summary(null.obj = null.obj.FR,
                                       covariate.interest = covariate.interest["FR-CRC"])

null.obj.DE <- melody.null.model(rel.abd = rel.abd["DE-CRC"], ref = "Coprococcus catus [ref_mOTU_v2_4874]")
summary.stats.DE <- melody.get.summary(null.obj = null.obj.DE,
                                       covariate.interest = covariate.interest["DE-CRC"])

## ----echo=TRUE, message=FALSE, warning=FALSE----------------------------------
# Concatenate summary statistics
summary.stats.all <- c(summary.stats.FR, summary.stats.DE)

## ----echo=TRUE----------------------------------------------------------------
# Meta-analysis to harmonize and combine summary statistics across studies
meta.result.2 <- melody.meta.summary(summary.stats = summary.stats.all, verbose = TRUE)

